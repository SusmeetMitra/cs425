# config.py

DB_HOST = "localhost"
DB_NAME = "realestate"
DB_USER = "postgres"
DB_PASSWORD = "postgres"
DB_PORT = 5432